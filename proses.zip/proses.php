<?php
session_start();
if(!isset($_SESSION['username'])) {
die("<script>window.location = '/'</script>");
} else{
}?>
<?php
require("../dee1ebcd105d3d47adf43aba6fd674e80d1dc35f/koneksi.php");
$user = $_SESSION['username']; 
$query = mysql_query("SELECT * FROM user WHERE username = '$user'");
$hasil = mysql_fetch_array($query);
$nama=$_POST['nama'];
$username=$_POST['username'];
$password=$_POST['password'];
$game=$_POST['game'];
$reseller = $_SESSION['username'];
$date=date('Y-m-d', time()+60*60*7);
if(!$nama || !$username) {
  echo "Error : Masih Ada Data Yang Kosong";
 } else { 
$cektanggal = mysql_query("SELECT * FROM member WHERE username = '$username'");
$cekjumlah = mysql_num_rows($cektanggal);
$cekhasil = mysql_fetch_array($cektanggal);
$tanggalsebelum = $cekhasil['expired'];
if ($_POST["durasi"] == '3') {
$fee='10000';
$durasi = '3';
$newdate = strtotime ( '+3 day' , strtotime ( $date ) ) ;
$newdate = date ( 'Y-m-d' , $newdate );
$perpan = strtotime ( '+3 day' , strtotime ( $tanggalsebelum ) ) ;
$perpan2 = date ( 'Y-m-d' , $perpan);
} else if ($_POST["durasi"]=='7') {
$fee='20000';
$durasi = '7';
$newdate = strtotime ( '+7 day' , strtotime ( $date ) ) ;
$newdate = date ( 'Y-m-d' , $newdate );
$perpan = strtotime ( '+7 day' , strtotime ( $tanggalsebelum ) ) ;
$perpan2 = date ( 'Y-m-d' , $perpan);
} else if ($_POST["durasi"]=='14') {
$fee='35000';
$durasi = '14';
$newdate = strtotime ( '+14 day' , strtotime ( $date ) ) ;
$newdate = date ( 'Y-m-d' , $newdate );
$perpan = strtotime ( '+14 day' , strtotime ( $tanggalsebelum ) ) ;
$perpan2 = date ( 'Y-m-d' , $perpan);
} else if ($_POST["durasi"]=='30') {
$fee='70000';
$durasi = '30';
$newdate = strtotime ( '+30 day' , strtotime ( $date ) ) ;
$newdate = date ( 'Y-m-d' , $newdate );
$perpan = strtotime ( '+30 day' , strtotime ( $tanggalsebelum ) ) ;
$perpan2 = date ( 'Y-m-d' , $perpan);
}else{
$fee = 'a';
}

if($hasil['saldo'] < $fee) {
echo 'Error : Saldo tidak mencukupi';
}else if($cekjumlah !== 0) {
echo 'Error : Username telah terdaftar.';
} else {
$sisa = $hasil['saldo']-$fee;
$simpan = mysql_query("INSERT INTO member (`name`, `reseller`, `username`, `password`,`game` , `expired`, `status`) VALUES ('$nama', '$reseller', '$username', '$password','$game', '$newdate', 'aktif')");
$simpan = mysql_query("UPDATE user SET saldo = saldo-$fee WHERE username = '$user'");
if($simpan) {
echo 'Register Data Succes
===================
Reseller : '.$user.'
Nama : '.$nama.'
HWID : '.$username.'
Password : '.$password.'
Game : '.$game.'
Durasi : '. $durasi.' Hari
Expired : '.$newdate.'
Saldo Sebelum : '.number_format($hasil['saldo'],0,',','.').'
Saldo Sesudah : '.number_format($sisa,0,',','.').'
===================';
} else {
echo 'ERROR';
}
}
}
?>